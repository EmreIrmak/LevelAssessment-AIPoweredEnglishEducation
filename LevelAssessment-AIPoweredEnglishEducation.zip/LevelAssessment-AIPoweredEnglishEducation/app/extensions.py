from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate

# Veritabanı ve Giriş yöneticisini burada oluşturuyoruz (Tertemiz bir sayfa)
db = SQLAlchemy()
login_manager = LoginManager()
migrate = Migrate()