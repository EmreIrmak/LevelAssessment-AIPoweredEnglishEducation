from app.extensions import db
# Question ve Response modellerini buraya ekledik 👇
from app.models import Report, ModuleType, CEFRLevel, Question, Response, ReportStatus, SessionQuestion
from app.services.nlp_service import NLPService
import json
from flask import current_app
from threading import Thread

class ReportService:
    @staticmethod
    def _level_from_percentage(score: float) -> CEFRLevel:
        # Simple, stable mapping to avoid anomalies (e.g., 54% -> B1 not C2)
        if score < 40:
            return CEFRLevel.A1
        if score < 50:
            return CEFRLevel.A2
        if score < 60:
            return CEFRLevel.B1
        if score < 70:
            return CEFRLevel.B2
        if score < 80:
            return CEFRLevel.C1
        return CEFRLevel.C2

    @staticmethod
    def generate_report(session):
        # 1. Genel İstatistikleri Hesapla (served total: unanswered lowers score)
        total_served = SessionQuestion.query.filter_by(session_id=session.id).count()
        correct_answers = session.responses.filter(Response.is_correct == True).count()
        score_percentage = (correct_answers / total_served * 100) if total_served > 0 else 0
        
        # 2. Modül Bazlı İstatistikler (Hata veren yer burasıydı, düzelttik)
        module_stats = {}
        for module in ModuleType:
            # Mantık: Bu oturumun cevaplarını al -> Question tablosuyla birleştir -> Modüle göre filtrele
            base_query = session.responses.join(Question).filter(Question.module == module)
            
            m_total = base_query.count()
            m_correct = base_query.filter(Response.is_correct == True).count()
            
            if m_total > 0:
                module_stats[module.value] = round((m_correct / m_total) * 100, 1)
            else:
                module_stats[module.value] = 0

        # 3. Nihai Seviyeyi Belirle (skor temelli, stabil)
        level_result = ReportService._level_from_percentage(score_percentage)
        final_level = level_result.value

        # 4. AI'dan Yol Haritası İste
        client = NLPService._get_client()
        if client:
            ai_feedback = (
                "<p><strong>AI raporu hazırlanıyor...</strong></p>"
                "<p class='text-muted'>Bu genelde birkaç saniye sürer. Sayfa otomatik güncellenecektir.</p>"
            )
            status = ReportStatus.ENRICHING
        else:
            ai_feedback = "AI servisine ulaşılamadı."
            status = ReportStatus.READY

        # 5. Veritabanına Kaydet
        report = Report(
            session_id=session.id,
            score=score_percentage,
            level_result=level_result,
            ai_feedback=ai_feedback,
            status=status,
        )
        db.session.add(report)
        db.session.commit()

        # Async enrichment (non-blocking) to keep report generation fast (<10s)
        if status == ReportStatus.ENRICHING:
            app = current_app._get_current_object()

            def _task():
                with app.app_context():
                    r = Report.query.get(report.id)
                    if not r:
                        return
                    try:
                        feedback = ReportService._get_ai_roadmap(final_level, module_stats, score_percentage)
                        r.ai_feedback = feedback
                        # Learning plan (separate section)
                        try:
                            r.learning_plan = ReportService._get_ai_learning_plan(final_level, module_stats)
                            r.learning_plan_error = None
                        except Exception as e:
                            r.learning_plan = None
                            r.learning_plan_error = str(e)
                        r.status = ReportStatus.READY
                        r.ai_error = None
                    except Exception as e:
                        r.status = ReportStatus.FAILED
                        r.ai_error = str(e)
                    db.session.commit()

            Thread(target=_task, daemon=True).start()
        
        return report

    @staticmethod
    def _get_ai_roadmap(level, stats, score):
        client = NLPService._get_client()
        if not client: return "AI servisine ulaşılamadı."

        prompt = f"""
        ACT AS: An expert English Teacher.
        TASK: Create a personalized study roadmap for a student in TURKISH.
        
        STUDENT DATA:
        - Level Result: {level}
        - Total Score: {score}%
        - Module Performance: {json.dumps(stats)}
        
        REQUIREMENTS:
        1. Analyze strengths and weaknesses based on module stats.
        2. Create a 3-step actionable roadmap to reach the NEXT level.
        3. Recommend specific topics.
        4. Use HTML formatting (<h3>, <ul>, <li>, <strong>). No markdown blocks.
        """

        try:
            chat = client.chat.completions.create(
                messages=[{"role": "user", "content": prompt}],
                model="llama-3.3-70b-versatile",
                temperature=0.7
            )
            return chat.choices[0].message.content
        except Exception as e:
            return f"Rapor oluşturulurken hata: {e}"

    @staticmethod
    def _get_ai_learning_plan(level, stats):
        client = NLPService._get_client()
        if not client:
            return "AI servisine ulaşılamadı."

        prompt = f"""
ACT AS: A professional English curriculum designer.
TASK: Create a personalized learning plan in TURKISH for the next 4 weeks.

STUDENT DATA:
- Level Result: {level}
- Module Performance: {json.dumps(stats)}

REQUIREMENTS:
1. Choose 2-3 weak modules and define weekly goals.
2. Provide a weekly plan (Week 1-4) with daily tasks (Mon-Sun) that are realistic.
3. Include practice types for Writing/Speaking (rubric-based) and Listening/Reading (academic).
4. Use HTML formatting (<h3>, <h4>, <ul>, <li>, <strong>). No markdown.
        """.strip()

        chat = client.chat.completions.create(
            messages=[{"role": "user", "content": prompt}],
            model="llama-3.3-70b-versatile",
            temperature=0.6,
        )
        return chat.choices[0].message.content