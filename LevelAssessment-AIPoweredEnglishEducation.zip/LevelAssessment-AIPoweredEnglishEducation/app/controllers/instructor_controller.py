from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from functools import wraps

from app.extensions import db
from app.models import UserRole, Student, TestSession, Report

instructor_bp = Blueprint("instructor", __name__)


def instructor_required(func):
    @wraps(func)
    def decorated_view(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for("auth.login"))
        if current_user.role not in (UserRole.ADMIN, UserRole.INSTRUCTOR):
            flash("Bu sayfaya erişim yetkiniz yok!", "danger")
            return redirect(url_for("auth.dashboard"))
        return func(*args, **kwargs)

    return decorated_view


@instructor_bp.route("/instructor/reports")
@login_required
@instructor_required
def all_reports():
    students = Student.query.order_by(Student.id.desc()).all()

    # Latest report per student (simple N+1 is ok for small SQLite demo)
    student_rows = []
    for s in students:
        last_session = (
            TestSession.query.filter_by(user_id=s.id).order_by(TestSession.start_time.desc()).first()
        )
        last_report = Report.query.filter_by(session_id=last_session.id).first() if last_session else None
        student_rows.append({"student": s, "session": last_session, "report": last_report})

    return render_template("instructor_reports.html", rows=student_rows)


@instructor_bp.route("/instructor/student/<int:student_id>/reports")
@login_required
@instructor_required
def student_reports(student_id: int):
    student = Student.query.get_or_404(student_id)
    sessions = TestSession.query.filter_by(user_id=student.id).order_by(TestSession.start_time.desc()).all()
    reports = []
    for sess in sessions:
        reports.append({"session": sess, "report": Report.query.filter_by(session_id=sess.id).first()})
    return render_template("instructor_student_reports.html", student=student, rows=reports)


