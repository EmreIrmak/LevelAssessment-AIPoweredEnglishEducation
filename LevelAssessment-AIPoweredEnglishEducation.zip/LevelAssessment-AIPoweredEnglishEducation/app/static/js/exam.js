function getCtx() {
  return window.__EXAM_CONTEXT__ || {};
}

async function postTechnicalEvent(eventType, message) {
  const ctx = getCtx();
  try {
    await fetch("/api/technical_event", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: ctx.sessionId,
        module: ctx.module,
        event_type: eventType,
        message: message || null,
      }),
    });
  } catch (e) {
    // swallow
  }
}

function initTimer() {
  const badge = document.getElementById("timerBadge");
  if (!badge) return;

  let remaining = parseInt(badge.getAttribute("data-remaining") || "0", 10);
  if (Number.isNaN(remaining)) remaining = 0;

  const tick = () => {
    remaining = Math.max(0, remaining - 1);
    badge.textContent = `${remaining}s`;
    if (remaining <= 10) badge.classList.add("bg-danger");
    if (remaining === 0) {
      postTechnicalEvent("timer_expired", "Client-side timer reached 0.");
      // Let backend enforce expiry + module advance
      const ctx = getCtx();
      window.location.href = `/exam/${ctx.sessionId}`;
    }
  };

  setInterval(tick, 1000);
}

function initSpeaking() {
  const ctx = getCtx();
  if (ctx.module !== "SPEAKING") return;

  const btnStart = document.getElementById("btnStartRec");
  const btnStop = document.getElementById("btnStopRec");
  const transcriptEl = document.getElementById("speakingTranscript");
  const audioFilenameInput = document.getElementById("audioFilenameInput");

  if (!btnStart || !btnStop || !transcriptEl) return;

  let stream = null;
  let recorder = null;
  let chunks = [];

  async function start() {
    try {
      chunks = [];
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getAudioTracks().forEach((t) => {
        t.addEventListener("ended", () => {
          postTechnicalEvent("mic_track_ended", "Microphone track ended unexpectedly.");
        });
      });

      recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunks.push(e.data);
      };
      recorder.onerror = (e) => {
        postTechnicalEvent("mediarecorder_error", String(e.error || e.name || "unknown"));
      };
      recorder.onstart = () => {
        btnStart.disabled = true;
        btnStop.disabled = false;
      };
      recorder.onstop = async () => {
        btnStart.disabled = false;
        btnStop.disabled = true;

        try {
          const blob = new Blob(chunks, { type: "audio/webm" });
          const fd = new FormData();
          fd.append("session_id", String(ctx.sessionId));
          fd.append("question_id", String(ctx.questionId));
          fd.append("module", ctx.module);
          fd.append("audio", blob, "speech.webm");

          const res = await fetch("/api/stt/transcribe", { method: "POST", body: fd });
          const data = await res.json();
          if (!data.ok) {
            await postTechnicalEvent("stt_failed", data.error || data.status || "unknown");
            alert(`Speech-to-text başarısız: ${data.error || data.status}`);
            return;
          }

          transcriptEl.value = data.transcript || "";
          if (audioFilenameInput && data.audio_filename) {
            audioFilenameInput.value = data.audio_filename;
          }
        } catch (e) {
          await postTechnicalEvent("stt_exception", String(e));
          alert("Speech-to-text sırasında teknik bir hata oluştu.");
        } finally {
          if (stream) {
            stream.getTracks().forEach((t) => t.stop());
            stream = null;
          }
        }
      };

      recorder.start();
    } catch (e) {
      await postTechnicalEvent("mic_access_denied", String(e));
      alert("Mikrofon erişimi alınamadı. Tarayıcı izinlerini kontrol edin.");
    }
  }

  function stop() {
    try {
      if (recorder && recorder.state !== "inactive") recorder.stop();
    } catch (e) {
      postTechnicalEvent("mediarecorder_stop_error", String(e));
    }
  }

  btnStart.addEventListener("click", start);
  btnStop.addEventListener("click", stop);
}

document.addEventListener("DOMContentLoaded", () => {
  initTimer();
  initSpeaking();
});


