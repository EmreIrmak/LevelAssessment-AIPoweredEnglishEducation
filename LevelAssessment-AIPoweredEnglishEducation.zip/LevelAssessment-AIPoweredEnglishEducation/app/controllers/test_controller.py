from flask import Blueprint, render_template, redirect, url_for, request, flash, current_app
from flask_login import login_required, current_user
from app.extensions import db
from app.models import (
    TestSession,
    Question,
    Response,
    ModuleType,
    QuestionType,
    SessionModuleAttempt,
    SessionQuestion,
    SessionQuestionStatus,
    ModuleAttemptStatus,
)
from app.services.nlp_service import NLPService
from app.services.adaptive_service import AdaptiveService
import json
from datetime import datetime, timedelta
from sqlalchemy import func
from app.models import CEFRLevel

test_bp = Blueprint("test", __name__)

# Full assessment order
MODULE_ORDER = [
    ModuleType.GRAMMAR,
    ModuleType.VOCABULARY,
    ModuleType.READING,
    ModuleType.WRITING,
    ModuleType.LISTENING,
    ModuleType.SPEAKING,
]

def _questions_per_module() -> int:
    return int(current_app.config.get("QUESTIONS_PER_MODULE") or 10)


def _get_time_limit_seconds(module: ModuleType) -> int:
    limits = current_app.config.get("MODULE_TIME_LIMITS") or {}
    return int(limits.get(module.value, 0) or 0)


def _get_or_create_attempt(session: TestSession) -> SessionModuleAttempt:
    attempt = SessionModuleAttempt.query.filter_by(
        session_id=session.id, module=session.current_module
    ).first()
    if not attempt:
        attempt = SessionModuleAttempt(
            session_id=session.id,
            module=session.current_module,
            time_limit_seconds=_get_time_limit_seconds(session.current_module),
            status=ModuleAttemptStatus.IN_PROGRESS,
        )
        db.session.add(attempt)
        db.session.commit()
    return attempt


def _remaining_seconds(attempt: SessionModuleAttempt) -> int | None:
    if not attempt.started_at or not attempt.time_limit_seconds:
        return None
    elapsed = datetime.utcnow() - attempt.started_at
    remaining = int(attempt.time_limit_seconds - elapsed.total_seconds())
    return max(0, remaining)


def _advance_module(session: TestSession):
    # move to next module (or finish exam)
    try:
        curr_idx = MODULE_ORDER.index(session.current_module)
        if curr_idx + 1 < len(MODULE_ORDER):
            session.current_module = MODULE_ORDER[curr_idx + 1]
            session.current_question_index = 0
            db.session.commit()
            return redirect(url_for("test.get_question", session_id=session.id))
    except ValueError:
        pass

    session.end_time = datetime.utcnow()
    session.is_completed = True
    db.session.commit()
    return redirect(url_for("report.show_result", session_id=session.id))

def _difficulty_candidates(target: CEFRLevel):
    order = [CEFRLevel.A1, CEFRLevel.A2, CEFRLevel.B1, CEFRLevel.B2, CEFRLevel.C1, CEFRLevel.C2]
    try:
        idx = order.index(target)
    except ValueError:
        idx = 0
    candidates = [order[idx]]
    for step in range(1, len(order)):
        lo = idx - step
        hi = idx + step
        if lo >= 0:
            candidates.append(order[lo])
        if hi < len(order):
            candidates.append(order[hi])
    return candidates

def _prefer_ai_questions() -> bool:
    return bool(current_app.config.get("PREFER_AI_QUESTIONS", True))

@test_bp.route("/start_exam")
@login_required
def start_exam():
    session = TestSession(user_id=current_user.id)
    db.session.add(session)
    db.session.commit()
    return redirect(url_for("test.get_question", session_id=session.id))


@test_bp.route("/exam/<int:session_id>/start_module", methods=["POST"])
@login_required
def start_module(session_id: int):
    session = TestSession.query.get_or_404(session_id)
    if session.user_id != current_user.id:
        return "Yetkisiz Erişim", 403

    attempt = _get_or_create_attempt(session)
    if not attempt.started_at:
        attempt.started_at = datetime.utcnow()
        attempt.status = ModuleAttemptStatus.IN_PROGRESS
        db.session.commit()
    return redirect(url_for("test.get_question", session_id=session.id))


@test_bp.route("/exam/<int:session_id>/finish_module", methods=["POST"])
@login_required
def finish_module(session_id: int):
    session = TestSession.query.get_or_404(session_id)
    if session.user_id != current_user.id:
        return "Yetkisiz Erişim", 403

    attempt = _get_or_create_attempt(session)
    attempt.ended_at = datetime.utcnow()
    attempt.status = ModuleAttemptStatus.COMPLETED
    db.session.commit()
    return _advance_module(session)


@test_bp.route("/exam/<int:session_id>", methods=["GET", "POST"])
@login_required
def get_question(session_id):
    session = TestSession.query.get_or_404(session_id)
    if session.user_id != current_user.id:
        return "Yetkisiz Erişim", 403

    attempt = _get_or_create_attempt(session)

    # Timer enforcement
    remaining = _remaining_seconds(attempt)
    if remaining == 0 and attempt.started_at and attempt.status == ModuleAttemptStatus.IN_PROGRESS:
        attempt.ended_at = datetime.utcnow()
        attempt.status = ModuleAttemptStatus.EXPIRED
        db.session.commit()
        flash(f"{session.current_module.value} süresi doldu. Sonraki bölüme geçiliyor.", "warning")
        return _advance_module(session)

    # --- POST: Cevap Verme Kısmı ---
    if request.method == "POST":
        action = request.form.get("action", "next")
        # allow navigation actions without answering
        if action == "prev":
            session.current_question_index = max(0, session.current_question_index - 1)
            db.session.commit()
            return redirect(url_for("test.get_question", session_id=session.id))

        question_id = request.form.get("question_id")
        user_answer = (request.form.get("option") or request.form.get("text_answer") or "").strip()
        audio_filename = request.form.get("audio_filename")

        question = Question.query.get(question_id)

        # Basit hata önlemi: Eğer soru silinmişse veya yoksa
        if not question:
            flash("Soru bulunamadı, bir sonrakine geçiliyor.", "warning")
            return redirect(url_for("test.get_question", session_id=session.id))

        # If user clicked Next without answering, treat as unanswered and allow navigation.
        if not user_answer:
            sq = SessionQuestion.query.filter_by(
                session_id=session.id,
                module=session.current_module,
                question_index=session.current_question_index,
            ).first()
            if sq and sq.status != SessionQuestionStatus.ANSWERED:
                sq.status = SessionQuestionStatus.SKIPPED
                db.session.commit()

            session.current_question_index = min(
                _questions_per_module(), session.current_question_index + 1
            )
            db.session.commit()
            return redirect(url_for("test.get_question", session_id=session.id))

        is_correct = False
        if question.question_type == QuestionType.MULTIPLE_CHOICE:
            is_correct = user_answer == question.correct_answer
        else:
            is_correct = NLPService.evaluate_open_ended(
                question.text, user_answer, session.current_difficulty.value
            )

        # Upsert: if user navigates back and changes an answer, update the existing row instead of inserting duplicates
        resp = (
            Response.query.filter_by(session_id=session.id, question_id=question.id)
            .order_by(Response.id.desc())
            .first()
        )
        if not resp:
            resp = Response(session_id=session.id, question_id=question.id)
            db.session.add(resp)

        resp.selected_option = (
            user_answer if question.question_type == QuestionType.MULTIPLE_CHOICE else None
        )
        resp.text_answer = (
            user_answer if question.question_type == QuestionType.OPEN_ENDED else None
        )
        resp.is_correct = is_correct
        resp.audio_filename = audio_filename or resp.audio_filename
        resp.transcript = user_answer if session.current_module == ModuleType.SPEAKING else resp.transcript
        resp.stt_provider = "groq" if (audio_filename or resp.audio_filename) else None
        resp.stt_status = "ok" if (audio_filename or resp.audio_filename) else resp.stt_status

        sq = SessionQuestion.query.filter_by(
            session_id=session.id,
            module=session.current_module,
            question_index=session.current_question_index,
        ).first()
        if sq:
            sq.status = SessionQuestionStatus.ANSWERED
            sq.answered_at = datetime.utcnow()

        session.current_question_index += 1

        # Modül Bitti mi?
        if session.current_question_index >= _questions_per_module():
            attempt.ended_at = datetime.utcnow()
            attempt.status = ModuleAttemptStatus.COMPLETED

        session.current_difficulty = AdaptiveService.calculate_next_level(session)
        db.session.commit()
        if session.current_question_index >= _questions_per_module():
            return redirect(url_for("test.get_question", session_id=session.id))
        return redirect(url_for("test.get_question", session_id=session.id))

    # --- GET: Soru Getirme Kısmı ---

    # intro screen (per module) until started
    if not attempt.started_at:
        return render_template(
            "exam_intro.html",
            session=session,
            attempt=attempt,
            time_limit_seconds=attempt.time_limit_seconds,
        )

    # module end / review screen
    if session.current_question_index >= _questions_per_module():
        skipped = (
            SessionQuestion.query.filter_by(session_id=session.id, module=session.current_module)
            .filter(SessionQuestion.status == SessionQuestionStatus.SKIPPED)
            .order_by(SessionQuestion.question_index.asc())
            .all()
        )
        return render_template(
            "exam_review.html",
            session=session,
            attempt=attempt,
            skipped=skipped,
            total=_questions_per_module(),
            remaining_seconds=remaining,
        )

    # navigation: only within already-generated questions for this module
    req_i = request.args.get("i", type=int)
    if req_i is not None:
        existing_sq = SessionQuestion.query.filter_by(
            session_id=session.id, module=session.current_module, question_index=req_i
        ).first()
        if existing_sq:
            session.current_question_index = req_i
            db.session.commit()

    # 1. Önce Veritabanına Bak (Çözülmemiş soru var mı?)
    sq = SessionQuestion.query.filter_by(
        session_id=session.id,
        module=session.current_module,
        question_index=session.current_question_index,
    ).first()

    # already generated for this index?
    if sq:
        new_q = sq.question
    else:
        served_question_ids = db.session.query(SessionQuestion.question_id).filter(
            SessionQuestion.session_id == session.id
        )

        new_q = None
        # 1) Prefer AI to keep questions fresh across sessions
        if _prefer_ai_questions():
            max_retries = 5
            for _ in range(max_retries):
                q_data = NLPService.generate_adaptive_question(
                    session.current_module.value, session.current_difficulty.value
                )
                if not (q_data and q_data.get("text")):
                    continue

                # Avoid duplicates within the same session by text match (best-effort)
                duplicate_check = Question.query.filter_by(text=q_data["text"]).first()
                if duplicate_check:
                    already_served = (
                        SessionQuestion.query.filter_by(
                            session_id=session.id, question_id=duplicate_check.id
                        ).first()
                        is not None
                    )
                    if already_served:
                        continue
                    # If it exists but wasn't served in THIS session, still reuse to avoid DB bloat
                    new_q = duplicate_check
                    break

                # Create a new AI-generated question row (fresh)
                try:
                    qt = QuestionType[q_data["question_type"]]
                except Exception:
                    qt = QuestionType.MULTIPLE_CHOICE

                new_q = Question(
                    text=q_data["text"],
                    module=session.current_module,
                    difficulty=session.current_difficulty,
                    question_type=qt,
                    options=json.dumps(q_data.get("options")) if q_data.get("options") else None,
                    correct_answer=q_data.get("correct_answer"),
                )
                db.session.add(new_q)
                db.session.commit()
                break

        # 2) Fallback to DB pool only if AI is unavailable/failed (or prefer_ai disabled)
        if not new_q:
            existing_q = None
            for diff in _difficulty_candidates(session.current_difficulty):
                existing_q = Question.query.filter(
                    Question.module == session.current_module,
                    Question.difficulty == diff,
                    ~Question.id.in_(served_question_ids),
                ).order_by(func.random()).first()
                if existing_q:
                    break
            if not existing_q:
                existing_q = Question.query.filter(
                    Question.module == session.current_module,
                    ~Question.id.in_(served_question_ids),
                ).order_by(func.random()).first()
            new_q = existing_q

        # 3) Last-resort fallback: if AI is down and pool is exhausted, allow repeats instead of hard-failing.
        if not new_q:
            repeat_any = Question.query.filter(
                Question.module == session.current_module
            ).order_by(func.random()).first()
            if repeat_any:
                new_q = repeat_any
                current_app.logger.warning(
                    "Question pool exhausted for module=%s; using repeat fallback. "
                    "Consider generating more questions or lowering QUESTIONS_PER_MODULE.",
                    session.current_module.value,
                )

    if not new_q:
        # Eğer soru bulunamazsa (çok nadir), kullanıcıyı bekletmemek için Dashboard'a at veya geçici hata ver
        flash(
            "Soru üretilirken bağlantı sorunu yaşandı. Lütfen tekrar deneyin.", "danger"
        )
        return redirect(url_for("auth.dashboard"))

    # persist question for navigation within this module
    if not sq:
        sq = SessionQuestion(
            session_id=session.id,
            module=session.current_module,
            question_index=session.current_question_index,
            question_id=new_q.id,
            status=SessionQuestionStatus.SERVED,
        )
        db.session.add(sq)
        db.session.commit()

    # HTML'e göndermek için Options ayarı
    options_dict = None
    if new_q.options:
        try:
            options_dict = (
                json.loads(new_q.options)
                if isinstance(new_q.options, str)
                else new_q.options
            )
        except:
            pass

    existing_response = (
        Response.query.filter_by(session_id=session.id, question_id=new_q.id)
        .order_by(Response.id.desc())
        .first()
    )

    return render_template(
        "exam.html",
        question=new_q,
        options=options_dict,
        session=session,
        index=session.current_question_index + 1,
        total=_questions_per_module(),
        remaining_seconds=remaining,
        attempt=attempt,
        sq=sq,
        existing_response=existing_response,
    )
