import os
from groq import Groq
from flask import current_app
import json
import re


class NLPService:
    @staticmethod
    def _get_client():
        api_key = current_app.config.get("GROQ_API_KEY")
        if not api_key:
            # If this is None, no Groq calls will happen (usage will stay at 0)
            current_app.logger.warning("GROQ_API_KEY is missing; Groq client not initialized.")
            return None
        return Groq(api_key=api_key)

    @staticmethod
    def generate_adaptive_question(module, difficulty):
        client = NLPService._get_client()
        if not client:
            return None

        # ETS-style high-stakes diagnostic prompt (JSON-only output)
        system_prompt = """
You are a Senior Assessment Developer for ETS (creators of TOEFL).
Your ONLY job is to output valid JSON. Do NOT write explanations. Do NOT write code blocks.
        """.strip()

        module_instructions = module
        if module == "Listening":
            module_instructions = (
                "Listening (Provide an academic mini-lecture transcript inside the question stem. "
                "Start the stem with 'Audio Script:' and then ask a comprehension question.)"
            )
        elif module == "Speaking":
            module_instructions = (
                "Speaking (Provide an academic speaking prompt; the student will respond orally. "
                "Ask for an organized response with examples.)"
            )
        elif module == "Writing":
            module_instructions = (
                "Writing (Provide an academic short essay prompt; specify word range and require a thesis + support.)"
            )

        user_prompt = f"""
ROLE: You are a Senior Assessment Developer for ETS (creators of TOEFL). Your task is to write high-stakes diagnostic questions.

TASK: Create 1 question for the module below at CEFR level {difficulty}.
Module: {module_instructions}

CRITICAL DESIGN RULES:
1) Academic Tone: Use formal, university-level English. Avoid conversational slang.
2) Distractor Quality (MOST IMPORTANT): Wrong options must be plausible to a lower-level student, grammatically consistent, and clearly incorrect to a proficient reader based on logic/nuance. Avoid easy fillers (e.g., 'None of the above').
3) Difficulty: Require reasoning/nuance; avoid keyword matching.

OUTPUT REQUIREMENTS:
- Output ONLY valid JSON.
- For MULTIPLE_CHOICE: provide 4 options A-D and a single correct_answer letter.
- For OPEN_ENDED: set options to null and correct_answer to null.

REQUIRED JSON FORMAT:
{{
  "text": "Question stem...",
  "options": {{"A": "...", "B": "...", "C": "...", "D": "..."}}, 
  "correct_answer": "A",
  "question_type": "MULTIPLE_CHOICE" 
}}
        """.strip()

        try:
            chat_completion = client.chat.completions.create(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                model="llama-3.3-70b-versatile",  # Çok hızlı ve ücretsiz model
                temperature=0.4,
            )

            response_content = chat_completion.choices[0].message.content.strip()

            # Bazen ```json etiketi koyar, temizleyelim
            if "```" in response_content:
                response_content = re.sub(r"```json\s*|\s*```", "", response_content)

            # JSON'ı temizle (Llama bazen en sona açıklama ekler, sadece { } arasını alalım)
            json_match = re.search(r"\{.*\}", response_content, re.DOTALL)
            if json_match:
                response_content = json_match.group(0)

            return json.loads(response_content)

        except Exception as e:
            print(f"Groq API Error: {e}")
            return None

    @staticmethod
    def generate_10_mcq_for_module(module: str, difficulty: str = "B2"):
        """
        Creates 10 multiple-choice questions for a single module using the requested ETS prompt.
        Returns a list[dict] with items in the same JSON schema as generate_adaptive_question.
        """
        client = NLPService._get_client()
        if not client:
            return []

        system_prompt = """
You are a Senior Assessment Developer for ETS (creators of TOEFL).
Your ONLY job is to output valid JSON. Do NOT write explanations. Do NOT write code blocks.
        """.strip()

        user_prompt = f"""
ROLE: You are a Senior Assessment Developer for ETS (creators of TOEFL). Your task is to write high-stakes diagnostic questions.

TASK: Create 10 multiple-choice questions for the module "{module}" at averagely {difficulty} CEFR proficiency level.

CRITICAL DESIGN RULES:
1) Academic Tone: Use formal, university-level English. Avoid conversational slang.
2) Distractor Quality (MOST IMPORTANT): The wrong options (distractors) must be:
   - Plausible to a lower-level student.
   - Grammatically consistent with the stem.
   - Clearly incorrect to a native or proficient speaker based on logic or nuance.
   - AVOID easy fillers like "None of the above".
3) Difficulty: Since the level is {difficulty}, the question should require critical thinking, not just keyword matching.

OUTPUT REQUIREMENTS:
- Output ONLY valid JSON.
- Output a JSON array of exactly 10 items.
- Each item must match this schema:
  {{
    "text": "Question stem...",
    "options": {{"A": "...", "B": "...", "C": "...", "D": "..."}},
    "correct_answer": "A",
    "question_type": "MULTIPLE_CHOICE"
  }}
        """.strip()

        try:
            chat_completion = client.chat.completions.create(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                model="llama-3.3-70b-versatile",
                temperature=0.4,
            )

            response_content = chat_completion.choices[0].message.content.strip()
            if "```" in response_content:
                response_content = re.sub(r"```json\s*|\s*```", "", response_content)

            json_match = re.search(r"\[.*\]", response_content, re.DOTALL)
            if json_match:
                response_content = json_match.group(0)

            data = json.loads(response_content)
            if isinstance(data, list):
                # Best-effort filter to valid items
                out = []
                for item in data:
                    if not isinstance(item, dict):
                        continue
                    if not item.get("text"):
                        continue
                    if not isinstance(item.get("options"), dict):
                        continue
                    if item.get("question_type") != "MULTIPLE_CHOICE":
                        item["question_type"] = "MULTIPLE_CHOICE"
                    out.append(item)
                return out[:10]
            return []
        except Exception as e:
            print(f"Groq API Error: {e}")
            return []

    @staticmethod
    def generate_question_bank(modules, difficulty="B2", count_per_module=10):
        """
        Generate a question bank using the requested ETS prompt.
        Returns: { "Grammar": [q,...], ... }
        """
        bank = {}
        for m in modules:
            if int(count_per_module) == 10:
                bank[m] = NLPService.generate_10_mcq_for_module(m, difficulty=difficulty)
            else:
                # fallback: generate one-by-one
                items = []
                for _ in range(count_per_module):
                    q = NLPService.generate_adaptive_question(m, difficulty)
                    if q:
                        items.append(q)
                bank[m] = items
        return bank

    @staticmethod
    def evaluate_open_ended(question_text, user_answer, current_level):
        client = NLPService._get_client()
        if not client:
            return True

        system_prompt = (
            'You are an expert English teacher and CEFR evaluator. '
            'Evaluate using contemporary standard English usage (2020s), focusing on communicative adequacy, '
            'clarity, coherence, and appropriate vocabulary/grammar for the target CEFR level. '
            'Be reasonably tolerant of minor mistakes that do not impede meaning. '
            'Output ONLY valid JSON: {"passed": true} or {"passed": false}.'
        )

        user_prompt = f"""
        Question: {question_text}
        Student Answer: {user_answer}
        Target Level: {current_level}
        
        Is this answer acceptable for the target level in contemporary English?
        """

        try:
            chat_completion = client.chat.completions.create(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                model="llama3-8b-8192",
                temperature=0.1,
            )

            text = chat_completion.choices[0].message.content.strip()
            # Temizlik
            json_match = re.search(r"\{.*\}", text, re.DOTALL)
            if json_match:
                text = json_match.group(0)

            return json.loads(text).get("passed", False)
        except:
            return False
